//
//  WGInfoEditVC.swift
//  WGNewsProject
//
//  Created by abox on 2021/1/7.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class WGInfoEditVC: ViewController {

    @IBOutlet weak var height: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addCustemNavgation()
    }
    
    func addCustemNavgation() {
        height.constant = CGFloat(SafeAreaTopHeight)
        let custemNav = WGCustemNavgation.init(frame: CGRect.init(x: 0, y: 0, width: Int(kScreenWidth), height: SafeAreaTopHeight))
        self.view.addSubview(custemNav)
        custemNav.setNavgationTitle(titleString: "用户信息" , rightString: "保存")
        custemNav.changeBlock = {[weak self] flag in
            if flag {
                self!.navigationController?.popViewController(animated: true)
            }
        }
    }
    
}
