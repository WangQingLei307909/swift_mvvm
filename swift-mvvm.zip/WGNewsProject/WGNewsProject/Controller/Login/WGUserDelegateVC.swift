//
//  WGUserDelegateVC.swift
//  WGNewsProject
//
//  Created by abox on 2021/1/7.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import WebKit
class WGUserDelegateVC: ViewController {

    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var height: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addCustemNavgation()
        loadWebUrl()
    }
    
    func addCustemNavgation() {
        height.constant = CGFloat(SafeAreaTopHeight)
        let custemNav = WGCustemNavgation.init(frame: CGRect.init(x: 0, y: 0, width: Int(kScreenWidth), height: SafeAreaTopHeight))
        self.view.addSubview(custemNav)
        custemNav.setNavgationTitle(titleString: "用户协议")
        custemNav.changeBlock = {[weak self] flag in
            if flag {
                self!.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    func loadWebUrl() {
        let rul = URL.init(string:("https://www.baidu.com"))
        let request = URLRequest(url:rul!)
        webView?.load(request)
        self.view.addSubview(webView!)
    }
    
}
