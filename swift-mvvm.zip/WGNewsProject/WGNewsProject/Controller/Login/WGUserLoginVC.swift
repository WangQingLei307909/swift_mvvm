//
//  WGUserLoginVC.swift
//  WGNewsProject
//
//  Created by abox on 2021/1/7.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import CLToast
class WGUserLoginVC: ViewController {

    @IBOutlet weak var verificationCode: UIButton!
    @IBOutlet weak var height: NSLayoutConstraint!
    @IBOutlet weak var phoneTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        height.constant = CGFloat(SafeAreaTopHeight)
        SwiftTool.theViewSetsTheBorderLineAndWidth(view: verificationCode, color: UIColor.CSSHex("#999999"), width: 1)
    }
    
    @IBAction func delegateAction(_ sender: Any) {
        self.navigationController?.pushViewController(WGUserDelegateVC(), animated: true)
    }
    
    @IBAction func closeAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func getVerificationCodeAction(_ sender: Any) {
        if SwiftTool.isEmptyOrNull(value: phoneTextField.text as AnyObject) {
            CLToast.cl_show(msg: "手机号码为空")
            return
        }
        if !SwiftTool.isTelNumber(num: phoneTextField.text! as NSString) {
            CLToast.cl_show(msg: "手机号码不合法")
            return
        }
        let vertificationCode = WGVerificationCodeVC()
        vertificationCode.phoneString = phoneTextField.text!
        self.navigationController?.pushViewController(vertificationCode, animated: true)
    }
    
}
