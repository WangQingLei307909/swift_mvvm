//
//  WGVerificationCodeVC.swift
//  WGNewsProject
//
//  Created by abox on 2021/1/7.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import CLToast
class WGVerificationCodeVC: ViewController {

    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var verificationCodeTextField: UITextField!
    public var phoneString = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        addCustemNavgation()
    }

    func addCustemNavgation() {
        SwiftTool.theViewSetsTheBorderLineAndWidth(view: loginButton, color: UIColor.CSSHex("#999999"), width: 1)
        let custemNav = WGCustemNavgation.init(frame: CGRect.init(x: 0, y: 0, width: Int(kScreenWidth), height: SafeAreaTopHeight))
        self.view.addSubview(custemNav)
        custemNav.setNavgationTitle(titleString: "验证码")
        custemNav.changeBlock = {[weak self] flag in
            if flag {
                self!.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    @IBAction func loginAction(_ sender: Any) {
        if SwiftTool.isEmptyOrNull(value: verificationCodeTextField.text as AnyObject) {
            CLToast.cl_show(msg: "验证码为空")
            return
        }
        UserDefaults.standard.setValue(phoneString, forKey: sxUserPhone)
        UserDefaults.standard.set(true, forKey: sxUserLoginStatus)
        let index = (self.navigationController?.viewControllers.index(of: self))!
        self.navigationController?.popToViewController((self.navigationController?.viewControllers[index - 2])!, animated: true)
    }
    
}
