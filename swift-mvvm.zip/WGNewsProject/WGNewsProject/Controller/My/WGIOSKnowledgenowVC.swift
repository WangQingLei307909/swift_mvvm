//
//  WGIOSKnowledgenowVC.swift
//  WGNewsProject
//
//  Created by abox on 2021/1/12.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class WGIOSKnowledgenowVC: ViewController{

    @IBOutlet weak var height: NSLayoutConstraint!
    @IBOutlet weak var tableView: UITableView!
    let dataSource   = ["『GCD』详尽总结","『RunLoop』详尽总结","『NSOperation、NSOperationQueue』详尽总结","『Runtime』详尽总结"]
    let cellIdentify = "WGIOSKnowViewCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addCustemNavgation()
        setUpTableView()
    }

    func addCustemNavgation() {
        height.constant = CGFloat(SafeAreaTopHeight)
        let custemNav = WGCustemNavgation.init(frame: CGRect.init(x: 0, y: 0, width: Int(kScreenWidth), height: SafeAreaTopHeight))
        self.view.addSubview(custemNav)
        custemNav.setNavgationTitle(titleString: "iOS相关知识")
        custemNav.changeBlock = {[weak self] flag in
            self!.navigationController?.popViewController(animated: true)
        }
    }
    
    func setUpTableView() {
        tableView.register(UINib.init(nibName: cellIdentify, bundle: nil), forCellReuseIdentifier: cellIdentify)
    }
    
}

extension WGIOSKnowledgenowVC: UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentify, for: indexPath) as! WGIOSKnowViewCell
        cell.setCellData(string: dataSource[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return WGIOSKnowViewCell.cellHeight()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
            case 0:
                self.navigationController?.pushViewController(WGIOS_GCD_VC(), animated: true)
            break
            case 1:
                self.navigationController?.pushViewController(WGIOS_Runloop_VC(), animated: true)
            break
            case 2:
                self.navigationController?.pushViewController(WGIOS_Operation_Queue_VC(), animated: true)
            break
            case 3:
                self.navigationController?.pushViewController(WGIOS_Runtime_VC(), animated: true)
            break
            default:
            break
        }
        
    }
    
}
