//
//  WGMyVC.swift
//  WGWeather
//
//  Created by abox on 2020/12/26.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

class WGMyVC: ViewController{
    
    @IBOutlet weak var loginOutButton: UIButton!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet var headerView: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewWillAppear(_ animated: Bool) {
        if UserDefaults.standard.bool(forKey: sxUserLoginStatus) {
            userNameLabel.text = (UserDefaults.standard.object(forKey: sxUserPhone) as! String)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpDisplayContent()
    }
    
    @IBAction func moreAction(_ sender: Any) {
        self.navigationController?.pushViewController(WGUserLoginVC(), animated: true)
    }
    
    @IBAction func qrcodeAction(_ sender: Any) {
        self.navigationController?.pushViewController(ScaningViewController(), animated: true)
    }
    
    // MARK:- swift知识点总结
    /// swift知识点
    /// - Parameter sender: sender description
    @IBAction func swiftAction(_ sender: Any) {
        self.navigationController?.pushViewController(WGIOSKnowledgenowVC(), animated: true)
    }
    
    @IBAction func infoAction(_ sender: Any) {
        self.navigationController?.pushViewController(WGInfoEditVC(), animated: true)
    }
    
    @IBAction func loginOutAction(_ sender: Any) {
        if UserDefaults.standard.bool(forKey: sxUserLoginStatus) {
            UserDefaults.standard.set(false, forKey: sxUserLoginStatus)
            userNameLabel.text = ""
        }
    }
    
    func setUpDisplayContent() {
        if #available(iOS 11.0, *){
            tableView.contentInsetAdjustmentBehavior = .never
        }
        SwiftTool.theViewSetsTheBorderLineAndWidth(view: loginOutButton, color: UIColor.CSSHex("#999999"), width: 1)
        headerView.frame = CGRect.init(x: 0, y: 0, width: kScreenWidth, height: 700)
        tableView.tableHeaderView = headerView
    }

}

extension WGMyVC:UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return UITableViewCell.init()
    }
    
}
