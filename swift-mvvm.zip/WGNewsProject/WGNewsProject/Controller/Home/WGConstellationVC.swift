//
//  WGConstellationVC.swift
//  WGNewsProject
//
//  Created by abox on 2021/1/4.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import CLToast
class WGConstellationVC: ViewController{
    
    let viewmodel = WGHomeViewModel()
    @IBOutlet      var headerView: UIView!
    @IBOutlet weak var height: NSLayoutConstraint!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var womanTextField: UITextField!
    @IBOutlet weak var manTextField: UITextField!
    @IBOutlet weak var attentionLabel: UILabel!
    @IBOutlet weak var loveLabel: UILabel!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var indexLabel: UILabel!
    
    @IBAction func manAction(_ sender: UIButton) {
        let constellationVC = WGSelectConstellationVC()
        constellationVC.selectBlock = { constellation in
            if sender.tag == 1 {
                self.manTextField.text = constellation
            } else {
                self.womanTextField.text = constellation
            }
        }
        self.present(constellationVC, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addCustemNavgation()
        tableViewSetUp()
    }

    func addCustemNavgation() {
        height.constant = CGFloat(SafeAreaTopHeight)
        let custemNav = WGCustemNavgation.init(frame: CGRect.init(x: 0, y: 0, width: Int(kScreenWidth), height: SafeAreaTopHeight))
        self.view.addSubview(custemNav)
        custemNav.setNavgationTitle(titleString: "星座匹配", rightString: "匹配")
        custemNav.changeBlock = {[weak self] flag in
            if flag {
                self!.navigationController?.popViewController(animated: true)
            } else {
                self!.getConstellationData()
            }
        }
    }
    
    func tableViewSetUp() {
        headerView.frame = CGRect.init(x: 0, y: 0, width: kScreenWidth, height: 1000)
        tableView.tableHeaderView = headerView
    }
    
    func getConstellationData() {
        if SwiftTool.isEmptyOrNull(value: manTextField?.text as AnyObject?) && SwiftTool.isEmptyOrNull(value: womanTextField?.text as AnyObject?) {
            CLToast.cl_show(msg: "请选择星座")
            return
        }
        viewmodel.setCallBackData(successCallBack: { ( success ) -> (Void) in
            self.displayData(model: success as! WGConstellationModel)
        }, failedCallback: { ( failString ) in
            CLToast.cl_show(msg: failString)
        }) { ( errorString ) in
            CLToast.cl_show(msg: errorString)
        }
        let paramterDic = ["key":"3fb298084b8b176484f04f887cbe41c6",
                           "men":manTextField.text!,
                           "women":womanTextField.text!]
        viewmodel.getConstellationData(paramterDic: paramterDic as NSDictionary)
    }
    
    func displayData(model:WGConstellationModel) {
        indexLabel.text     = model.zhishu
        dateLabel.text      = model.xiangyue
        resultLabel.text    = model.jieguo
        loveLabel.text      = model.lianai
        attentionLabel.text = model.zhuyi
    }
    
}
