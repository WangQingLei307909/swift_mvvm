//
//  WGHomeVC.swift
//  WGWeather
//
//  Created by abox on 2020/12/26.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit
import CLToast
class WGHomeVC: ViewController {
    
    
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet var headerView: UIView!
    @IBOutlet weak var temLabel: UILabel!
    @IBOutlet weak var windLabel: UILabel!
    @IBOutlet weak var airPressureLabel: UILabel!
    @IBOutlet weak var imageViews: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    var weatherModel = WGWeatherModel()
    
    @IBAction func cityAction(_ sender: Any) {
        let cityVc = WGCityVC()
        cityVc.citySelectback = { [weak self] cityName, cityCode in
            self!.cityLabel.text = cityName
            var cityString = ""
            if cityName.contains("市") {
                cityString = cityName.replacingOccurrences(of: "市", with: "")
            } else {
                cityString = cityName
            }
            self!.getWeather(city: cityString)
        }
        self.navigationController?.pushViewController(cityVc, animated: true)
    }
    
    @IBAction func shareAction(_ sender: Any) {
        self.navigationController?.pushViewController(WGConstellationVC(), animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewSetUp()
        
        let array:Array = [0,1,2,9,8]
        let map = array.map({"\($0)" + "sssss"})
        print(map)
        let filter = array.filter({$0 % 2 == 0})
        print(filter)
        let reduce = array.reduce("") { $0 + "\($1)" }
        print(reduce)
        let sort = array.sorted(by: <)
        print(sort)
        
//        getWeather(city: "北京")
    }
    
    func tableViewSetUp() {
        headerView.frame = CGRect.init(x: 0, y: 0, width: kScreenWidth, height: 180)
        tableView.tableHeaderView = headerView
        tableView.register(UINib.init(nibName: "WGWeatherViewCell", bundle: nil), forCellReuseIdentifier:"WGWeatherViewCell")
    }
    
    func getWeather(city:String) {
        let viewmodel = WGNewsViewModelClass()
        viewmodel.setCallBackData(successCallBack: { ( success ) -> (Void) in
            self.displayWeatherData(model: success as! WGWeatherModel)
        }, failedCallback: { ( failString ) in
            CLToast.cl_show(msg: failString)
        }) { ( errorString ) in
            CLToast.cl_show(msg: errorString)
        }
        let paramterDic = ["city":city,"key":"8f1048baa70489c85928ec56dba7550a"]
        viewmodel.getCurrentAndFutureWeather(paramterDic: paramterDic as NSDictionary)
    }
    
    /// 展示天气信息
    /// - Parameter resultDic: 数据
    func displayWeatherData(model:WGWeatherModel) {
        weatherModel = model;
        let currentModel = model.realtime
        temLabel.text    = currentModel.temperature + "℃"
        windLabel.text   = currentModel.direct + "  " + currentModel.power
        airPressureLabel.text = currentModel.info + "  " + "湿度" + currentModel.humidity + "%"
        WGWeatherViewCell.displayImageView(string: currentModel.info,imageViews: imageViews)
        tableView.reloadData()
    }
    
    
}

extension WGHomeVC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return weatherModel.future.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WGWeatherViewCell", for: indexPath) as! WGWeatherViewCell
        if indexPath.row < weatherModel.future.count {
            cell.setCellData(model: weatherModel.future[indexPath.row] as! WGFutureWeatherModel)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return WGWeatherViewCell.cellHeight()
    }
}
