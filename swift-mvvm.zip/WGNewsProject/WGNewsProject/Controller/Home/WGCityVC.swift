//
//  WGCityVC.swift
//  WGWeather
//
//  Created by abox on 2020/12/26.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

class WGCityVC: ViewController{
    
    //给闭包起个别名
    typealias CitySelectback   = (String,String)->()
    var citySelectback : CitySelectback?
    var dataSource = NSMutableArray()
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var height: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        addCustemNavgation()
        tableViewSetUp()
        getSourceData()
    }

    func getSourceData() {
        let array = NSArray.init(contentsOfFile: Bundle.main.path(forResource: "CityData", ofType: "plist")!)!
        for item in array {
            dataSource.add(WGCityModel.jsonDataToModel(paramterDic: item as! NSDictionary))
        }
        tableView.reloadData()
    }
    
    
}

extension WGCityVC{
    func addCustemNavgation() {
        height.constant = CGFloat(SafeAreaTopHeight)
        let custemNav = WGCustemNavgation.init(frame: CGRect.init(x: 0, y: 0, width: Int(kScreenWidth), height: SafeAreaTopHeight))
        self.view.addSubview(custemNav)
        custemNav.setNavgationTitle(titleString: "城市列表")
        custemNav.changeBlock = { [weak self]  flag in
            if flag {
                self!.navigationController?.popViewController(animated: true)
            }
        }
    }
}

extension WGCityVC: UITableViewDataSource,UITableViewDelegate{
    
    func tableViewSetUp() {
        tableView.register(UINib.init(nibName: "WGCityViewCell", bundle: nil), forCellReuseIdentifier: "WGCityViewCell")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let model = dataSource.object(at: section) as! WGCityModel
        return model.citys.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WGCityViewCell", for: indexPath) as! WGCityViewCell
        let model = dataSource.object(at: indexPath.section) as! WGCityModel
        if indexPath.row < model.citys.count {
            cell.setCellData(model: model.citys[indexPath.row] as! WGDetaileCityModel)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if  indexPath.section < dataSource.count {
            let cityModel = dataSource.object(at: indexPath.section) as! WGCityModel
            let model = cityModel.citys.object(at: indexPath.row) as! WGDetaileCityModel
            citySelectback!(model.city_name,model.city_key)
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return WGCityViewCell.cellHeight()
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 45
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: kScreenWidth, height: 45))
        headerView.backgroundColor = UIColor.CSSHex("#F5F5F5")
        let sectionLabel = UILabel.init(frame: CGRect.init(x: 15, y: 0, width: kScreenWidth - 15, height: 44))
        sectionLabel.font = UIFont.systemFont(ofSize: 15)
        sectionLabel.textColor = UIColor.CSSHex("#323232")
        if section < dataSource.count {
            let model = dataSource.object(at: section) as! WGCityModel
            sectionLabel.text = model.initial
        }
        let lineView = UIView.init(frame: CGRect.init(x: 15, y: 44, width: kScreenWidth - 15, height: 1))
        lineView.backgroundColor = UIColor.CSSHex("#F5F5F5")
        headerView.addSubview(sectionLabel)
        headerView.addSubview(lineView)
        return headerView
    }
}
