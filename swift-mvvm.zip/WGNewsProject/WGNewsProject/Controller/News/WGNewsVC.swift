//
//  WGNewsVC.swift
//  WGNewsProject
//
//  Created by abox on 2020/12/29.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit
import SGPagingView
let buttonWidth = 0 
class WGNewsVC: ViewController {

    /// 标题和内容
    private var pageTitleView: SGPageTitleView?
    private var pageContentView: SGPageContentScrollView?
    let search = WGNewsSearchVC()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpCommonData()
        setUpNewsPageUI()
    }

    func setUpCommonData() {
        let nav = WGSearchNavagtion.init(frame: CGRect(x: 0, y: 0, width: Int(kScreenWidth), height: SafeAreaTopHeight))
        nav.searchClosure = { [weak self] searchString in
            self!.search.contentString = searchString
            self!.navigationController?.pushViewController(self!.search, animated: true)
        }
        self.view.addSubview(nav)
    }
    
}

// MARK: - 设置选择控制器
extension WGNewsVC {
    /// 设置 UI
    private func setUpNewsPageUI() {
        let titles = ["头条","社会","国内","国际","娱乐","体育","军事","科技","财经","时尚"]
        let types  = ["top","shehui","guonei","guoji","yule","tiyu","junshi","keji","caijing","shishang"]
        // 标题名称的数组
        let configuration = SGPageTitleViewConfigure()
        configuration.indicatorColor = .clear
        // 标题名称的数组
        self.pageTitleView = SGPageTitleView(frame: CGRect(x: 0, y: SafeAreaTopHeight, width: Int(kScreenWidth - CGFloat(buttonWidth)), height: 40), delegate: self as SGPageTitleViewDelegate, titleNames: titles, configure: configuration)
        self.pageTitleView!.backgroundColor = .clear
        self.pageTitleView?.resetIndicatorColor(UIColor.CSSHex("#323232"))
        self.pageTitleView?.resetTitleColor(UIColor.CSSHex("#999999"), titleSelectedColor: UIColor.CSSHex("#323232"))
        self.view.addSubview(self.pageTitleView!)
        //设置控制器
        var childvcs = [UIViewController]()
        for i in 0..<titles.count {
            let vc  = WGNewListVC()
            vc.type = types[i]
            childvcs.append(vc)
        }
        self.pageContentView = SGPageContentScrollView(frame: CGRect(x: 0, y: CGFloat(SafeAreaTopHeight + 40), width: kScreenWidth, height: kScreenHeight - CGFloat(SafeAreaTopHeight) - CGFloat(SafeAreaBottomHeight) - 49), parentVC: self, childVCs: childvcs)
        self.pageContentView!.delegatePageContentScrollView = self as SGPageContentScrollViewDelegate
        self.pageContentView?.backgroundColor = .clear
        self.view.addSubview(self.pageContentView!)
    }
}

// MARK: - SGPageTitleViewDelegate
extension WGNewsVC: SGPageTitleViewDelegate, SGPageContentScrollViewDelegate {
    /// 联动 pageContent 的方法
    func pageTitleView(_ pageTitleView: SGPageTitleView!, selectedIndex: Int) {
        self.pageContentView?.setPageContentScrollViewCurrentIndex(selectedIndex)
    }
    
    /// 联动 SGPageTitleView 的方法
    func pageContentScrollView(_ pageContentView: SGPageContentScrollView!, progress: CGFloat, originalIndex: Int, targetIndex: Int) {
        self.pageTitleView!.setPageTitleViewWithProgress(progress, originalIndex: originalIndex, targetIndex: targetIndex)
    }
    
}

