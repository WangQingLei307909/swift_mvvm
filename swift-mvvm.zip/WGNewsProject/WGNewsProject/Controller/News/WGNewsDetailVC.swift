//
//  WGNewsDetailVC.swift
//  WGNewsProject
//
//  Created by abox on 2021/3/8.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import WebKit
class WGNewsDetailVC: ViewController {

    @IBOutlet weak var height: NSLayoutConstraint!
    @IBOutlet weak var webView: WKWebView!
    var custemNav:WGCustemNavgation! = nil
    var urlString:String? = nil
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addCustemNavgation()
        loadWebUrl()
    }

    func addCustemNavgation() {
        height.constant = CGFloat(SafeAreaTopHeight)
        custemNav = WGCustemNavgation.init(frame: CGRect.init(x: 0, y: 0, width: Int(kScreenWidth), height: SafeAreaTopHeight))
        self.view.addSubview(custemNav)
        custemNav.setNavgationTitle(titleString: "")
        custemNav.changeBlock = {[weak self] flag in
            if flag {
                self!.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    func loadWebUrl() {
        guard let urlString = urlString else {
            return
        }
        let rul = URL.init(string:(urlString))
        let request = URLRequest(url:rul!)
        webView?.load(request)
        webView.uiDelegate = self
        webView.navigationDelegate = self
        self.view.addSubview(webView!)
    }
    
}

extension WGNewsDetailVC: WKUIDelegate,WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        webView.evaluateJavaScript("document.title") { (object, error) in
            guard let object = object else{
                return
            }
            self.custemNav.setNavgationTitle(titleString: object as! String)
        }
    }
}
