//
//  WGNewListVC.swift
//  WGNewsProject
//
//  Created by abox on 2020/12/29.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit
import CLToast
class WGNewListVC: ViewController{

    
    @IBOutlet weak var tableView: UITableView!
    public var type = String()
    var dataSource = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        refreshAndLoad()
//        getNewsListData()
    }

    func refreshAndLoad() {
        tableView.mj_header = MJRefreshNormalHeader.init(refreshingBlock: {
            self .getNewsListData()
        })
        tableView.register(UINib.init(nibName: "WGNewsListViewCell", bundle: nil), forCellReuseIdentifier: "WGNewsListViewCell")
        tableView.register(UINib.init(nibName: "WGNewsListOtherViewCell", bundle: nil), forCellReuseIdentifier: "WGNewsListOtherViewCell")
    }
    
    func getNewsListData() {
        let model = WGNewsViewModelClass()
        model.setCallBackData(successCallBack: { [weak self] ( success ) -> (Void) in
            self!.dataSource = success as! NSMutableArray
            self!.endRefreshing()
        }, failedCallback: { [weak self] ( failString ) in
            self!.endRefreshing()
        }) { [weak self] ( errorString ) in
            self!.endRefreshing()
        }
        let paramterDic = ["key":"d583503341753c1c49aa3ab2570cc48b","type":type]
        model.getNewsListData(paramterDic: paramterDic as NSDictionary)
    }
    
    func endRefreshing() {
        tableView.reloadData()
        tableView.mj_header?.endRefreshing()
    }
    
}

extension WGNewListVC:UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if  indexPath.row < dataSource.count {
            let model = dataSource.object(at: indexPath.row) as! WGNewsModel
            if SwiftTool.isEmptyOrNull(value: model.thumbnail_pic_s02 as AnyObject) && SwiftTool.isEmptyOrNull(value: model.thumbnail_pic_s03 as AnyObject) {
                let cell = tableView.dequeueReusableCell(withIdentifier: "WGNewsListViewCell", for: indexPath) as! WGNewsListViewCell
                cell.setCellData(model: model)
                return cell
            } else {
                let cell = tableView.dequeueReusableCell(withIdentifier: "WGNewsListOtherViewCell", for: indexPath) as! WGNewsListOtherViewCell
                cell.setCellData(model: model)
                return cell
            }
        } else {
            return UITableViewCell.init()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let model = dataSource.object(at: indexPath.row) as! WGNewsModel
        if SwiftTool.isEmptyOrNull(value: model.thumbnail_pic_s02 as AnyObject) && SwiftTool.isEmptyOrNull(value: model.thumbnail_pic_s03 as AnyObject) {
            return WGNewsListViewCell.cellHeight()
        } else {
            return WGNewsListOtherViewCell.cellHeight()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = dataSource.object(at: indexPath.row) as! WGNewsModel
        let newsDeatail = WGNewsDetailVC()
        newsDeatail.urlString = model.url
        self.navigationController?.pushViewController(newsDeatail, animated: true)
    }
    
}
