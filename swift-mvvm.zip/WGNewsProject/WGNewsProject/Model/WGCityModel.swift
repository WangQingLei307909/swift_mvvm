//
//  WGCityModel.swift
//  WGWeather
//
//  Created by abox on 2020/12/26.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

class WGCityModel: NSObject {
    
    public var initial   = String()
    public var citys     = NSMutableArray()
    
    public static func jsonDataToModel(paramterDic:NSDictionary) -> WGCityModel {
        let model = WGCityModel()
        model.initial   = paramterDic.object(forKey: "initial")   as! String
        model.citys = NSMutableArray.init()
        let array = paramterDic.object(forKey: "citys") as! NSArray
        for item in array {
            model.citys.add(WGDetaileCityModel.jsonDataToModel(paramterDic: item as! NSDictionary))
        }
        return model
    }
}

class WGDetaileCityModel: NSObject {
    public var city_key     = String()
    public var city_name    = String()
    public var initials     = String()
    public var pinyin       = String()
    public var short_name   = String()
    public static func jsonDataToModel(paramterDic:NSDictionary) -> WGDetaileCityModel {
        let model = WGDetaileCityModel()
        model.city_key      = paramterDic.object(forKey: "city_key")   as! String
        model.city_name     = paramterDic.object(forKey: "city_name")  as! String
        model.initials      = paramterDic.object(forKey: "initials")   as! String
        model.pinyin        = paramterDic.object(forKey: "pinyin")  as! String
        model.short_name    = paramterDic.object(forKey: "short_name")   as! String
        return model
    }
}
