//
//  WGWeatherModel.swift
//  WGNewsProject
//
//  Created by abox on 2020/12/31.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

class WGWeatherModel: NSObject {
    
    public var city       = String()
    public var realtime   = WGCurrentWeatherModel()
    public var future     = NSMutableArray()
    
    public static func jsonDataToModel(paramterDic:NSDictionary) -> WGWeatherModel {
        let model = WGWeatherModel()
        model.city   = paramterDic.object(forKey: "city")   as! String
        model.realtime = WGCurrentWeatherModel.jsonDataToModel(paramterDic: paramterDic.object(forKey: "realtime") as! NSDictionary)
        model.future = NSMutableArray.init()
        let array = paramterDic.object(forKey: "future") as! NSArray
        for item in array {
            model.future.add(WGFutureWeatherModel.jsonDataToModel(paramterDic: item as! NSDictionary))
        }
        return model
    }
    
}

class WGCurrentWeatherModel: NSObject {
    
    public var temperature   = String()
    public var humidity   = String()
    public var info   = String()
    public var wid   = String()
    public var direct   = String()
    public var power   = String()
    public var aqi   = String()
    
    public static func jsonDataToModel(paramterDic:NSDictionary) -> WGCurrentWeatherModel {
        let model = WGCurrentWeatherModel()
        model.temperature   = paramterDic.object(forKey: "temperature")   as! String
        model.humidity      = paramterDic.object(forKey: "humidity")   as! String
        model.info          = paramterDic.object(forKey: "info")   as! String
        model.wid           = paramterDic.object(forKey: "wid")   as! String
        model.direct        = paramterDic.object(forKey: "direct")   as! String
        model.power         = paramterDic.object(forKey: "power")   as! String
        return model
    }
    
}

class WGFutureWeatherModel: NSObject {
    
    public var date   = String()
    public var temperature   = String()
    public var weather   = String()
    public var wid   = WGFutureWidModel()
    public var direct   = String()
    
    public static func jsonDataToModel(paramterDic:NSDictionary) -> WGFutureWeatherModel {
        let model = WGFutureWeatherModel()
        model.date   = paramterDic.object(forKey: "date")   as! String
        model.temperature   = paramterDic.object(forKey: "temperature")   as! String
        model.weather   = paramterDic.object(forKey: "weather")   as! String
        model.direct   = paramterDic.object(forKey: "direct")   as! String
        model.wid   = WGFutureWidModel.jsonDataToModel(paramterDic: paramterDic.object(forKey: "wid") as! NSDictionary)
        return model
    }
    
}

class WGFutureWidModel: NSObject {
    
    public var day   = String()
    public var night   = String()
    
    public static func jsonDataToModel(paramterDic:NSDictionary) -> WGFutureWidModel {
        let model = WGFutureWidModel()
        model.day   = paramterDic.object(forKey: "day")   as! String
        model.night = paramterDic.object(forKey: "night")   as! String
        return model
    }
    
}
