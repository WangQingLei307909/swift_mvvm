//
//  WGConstellationModel.swift
//  WGNewsProject
//
//  Created by abox on 2021/1/4.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class WGConstellationModel: NSObject {
    public var men      = String()
    public var women    = String()
    public var zhishu   = String()
    public var bizhong  = String()
    public var xiangyue = String()
    public var tcdj     = String()
    public var jieguo   = String()
    public var lianai   = String()
    public var zhuyi    = String()
    
    public static func jsonDataToModel(paramterDic:NSDictionary) -> WGConstellationModel {
        let model = WGConstellationModel()
        model.men       = paramterDic.object(forKey: "men")   as! String
        model.women     = paramterDic.object(forKey: "women")   as! String
        model.zhishu    = paramterDic.object(forKey: "zhishu")   as! String
        model.bizhong   = paramterDic.object(forKey: "bizhong")   as! String
        model.xiangyue  = paramterDic.object(forKey: "xiangyue")   as! String
        model.tcdj      = paramterDic.object(forKey: "tcdj")   as! String
        model.jieguo    = paramterDic.object(forKey: "jieguo")   as! String
        model.lianai    = paramterDic.object(forKey: "lianai")   as! String
        model.zhuyi     = paramterDic.object(forKey: "zhuyi")   as! String
        return model
    }
}
