//
//  PublicModel.swift
//  AmzingBox
//
//  Created by abox on 2020/7/9.
//  Copyright © 2020 abox. All rights reserved.
//

import UIKit
class WGPublicModel: NSObject {
   
    public var userNameString   = String()
    public var userWidthString  = String()
    public var userHeightString = String()
    
    public static func jsonDataToModel(jsonString:String) -> WGPublicModel {
        let model = WGPublicModel()
        let dataDic = SwiftTool.jsonStringToDict(jsonString: jsonString)
        print(dataDic)
        model.userNameString   = dataDic.object(forKey: "user_name")   as! String
        model.userWidthString  = dataDic.object(forKey: "user_width")  as! String
        model.userHeightString = dataDic.object(forKey: "user_height") as! String
        return model
    }
    
}
