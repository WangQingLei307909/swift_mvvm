//
//  WGNewsModel.swift
//  WGNewsProject
//
//  Created by abox on 2020/12/29.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

class WGNewsModel: NSObject {
    public var uniquekey   = String()
    public var title   = String()
    public var date   = String()
    public var category   = String()
    public var author_name   = String()
    public var url   = String()
    public var thumbnail_pic_s   = String()
    public var thumbnail_pic_s02   = String()
    public var thumbnail_pic_s03   = String()
    
    public static func jsonDataToModel(paramterDic:NSDictionary) -> WGNewsModel {
        let model = WGNewsModel()
        model.uniquekey   = paramterDic.object(forKey: "uniquekey")   as! String
        model.title       = paramterDic.object(forKey: "title")   as! String
        model.date        = paramterDic.object(forKey: "date")   as! String
        model.category    = paramterDic.object(forKey: "category")   as! String
        model.author_name = paramterDic.object(forKey: "author_name")   as! String
        model.url         = paramterDic.object(forKey: "url")   as! String
        if !SwiftTool.isEmptyOrNull(value: paramterDic["thumbnail_pic_s"] as AnyObject) {
            model.thumbnail_pic_s     = paramterDic.object(forKey: "thumbnail_pic_s")   as! String
        }
        if !SwiftTool.isEmptyOrNull(value: paramterDic["thumbnail_pic_s02"] as AnyObject) {
            model.thumbnail_pic_s02   = paramterDic.object(forKey: "thumbnail_pic_s02")   as! String
        }
        if !SwiftTool.isEmptyOrNull(value: paramterDic["thumbnail_pic_s03"] as AnyObject) {
            model.thumbnail_pic_s03   = paramterDic.object(forKey: "thumbnail_pic_s03")  as! String
        }
        return model
    }
}
