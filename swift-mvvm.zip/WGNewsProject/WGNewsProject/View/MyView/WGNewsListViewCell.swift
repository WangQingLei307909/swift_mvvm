//
//  WGNewsListViewCell.swift
//  WGNewsProject
//
//  Created by abox on 2020/12/29.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

class WGNewsListViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var imageViews: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    public static func cellHeight()-> CGFloat {
        return 35 + 0.19 * kScreenWidth
    }
    
    public func setCellData(model:WGNewsModel) {
        titleLabel.text = model.title
        typeLabel.text  = model.author_name
        timeLabel.text  = model.date
        imageViews.kf.setImage(with: URL(string: model.thumbnail_pic_s), placeholder: UIImage(named: "qidong"), options: nil, progressBlock: nil) { (reslt) in

        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
