//
//  WGWeatherViewCell.swift
//  WGNewsProject
//
//  Created by abox on 2021/1/4.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class WGWeatherViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var imageViews: UIImageView!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    public static func cellHeight() -> CGFloat {
        return 70
    }
    
    func setCellData(model:WGFutureWeatherModel) {
        let array = model.temperature.components(separatedBy: "/")
        titleLabel.text = array.first! + "℃  ~  " + array.last! + "    " + model.weather
        messageLabel.text = model.direct
        dateLabel.text = model.date
        WGWeatherViewCell.displayImageView(string: model.weather,imageViews: imageViews)
    }
    
    public static func displayImageView(string:String,imageViews:UIImageView) {
        if string == "多云转晴" {
            imageViews.image = UIImage.init(named: "wg_duo_yun")
        } else if string == "晴转多云" {
            imageViews.image = UIImage.init(named: "wg_duo_yun")
        } else if string == "晴" {
            imageViews.image = UIImage.init(named: "wg_light_sunny")
        } else if string == "晴转多云" {
                   
        } else if string == "晴转多云" {
                   
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
