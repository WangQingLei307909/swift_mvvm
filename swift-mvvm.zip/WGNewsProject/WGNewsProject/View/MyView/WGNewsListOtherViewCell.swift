//
//  WGNewsListOtherViewCell.swift
//  WGNewsProject
//
//  Created by abox on 2020/12/29.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit
import Kingfisher
class WGNewsListOtherViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    @IBOutlet weak var imageView3: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    public static func cellHeight()-> CGFloat {
        return 150
    }
    
    public func setCellData(model:WGNewsModel) {
        titleLabel.text = model.title
        typeLabel.text  = model.author_name
        timeLabel.text  = model.date
        
        imageView1.kf.setImage(with: URL(string: model.thumbnail_pic_s), placeholder: UIImage(named: "qidong"), options: nil, progressBlock: nil) { (reslt) in
        }

        if !SwiftTool.isEmptyOrNull(value: model.thumbnail_pic_s02 as AnyObject) {
            imageView2.kf.setImage(with: URL(string: model.thumbnail_pic_s02), placeholder: UIImage(named: "qidong"), options: nil, progressBlock: nil) { (reslt) in
            }
        }
        if !SwiftTool.isEmptyOrNull(value: model.thumbnail_pic_s03 as AnyObject) {
            imageView3.kf.setImage(with: URL(string: model.thumbnail_pic_s03), placeholder: UIImage(named: "qidong"), options: nil, progressBlock: nil) { (reslt) in
            }
        }
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
