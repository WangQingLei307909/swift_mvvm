//
//  WGCityViewCell.swift
//  WGWeather
//
//  Created by abox on 2020/12/26.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

class WGCityViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    public static func cellHeight() -> CGFloat {
        return 42
    }
    
    public func setCellData( model : WGDetaileCityModel ) {
        titleLabel.text = model.city_name
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
