//
//  API.swift
//  GHMoyaNetWorkTest
//
//  Created by Guanghui Liao on 3/30/18.
//  Copyright © 2018 liaoworking. All rights reserved.

import Foundation
import Moya

enum API{
    /*
     post请求
     */
    case userLogin(parameters:[String:Any])//登录
    case userRegister(email:String,password:String)//注册
    case uploadHeadImage(parameters: [String:Any],imageDate:Data)//上传用户头像
    case newsList(parameters:[String:Any])//登录
    case weatherData(parameters:[String:Any])//登录
    case constellationData(parameters:[String:Any])//登录
    
    /*
     get请求
     */
    case easyRequset
    /*
     put请求
     */
    case changeAPi(parameters:[String:Any]) //更新数据
}

extension API:TargetType{
    var baseURL: URL {
        switch self {
        /*
          get请求
         */
        case .easyRequset:
            return URL.init(string:(Moya_baseURL))!
        /*
          put请求
         */
        case .changeAPi:
            return URL.init(string:(Moya_baseURL))!
        /*
          post请求
         */
        case .newsList:
            return URL.init(string:(Moya_newsBaseURL))!
        default:
            return URL.init(string:(Moya_weatherBaseURL))!
        }
    }
    
    var path: String {
        switch self {
        /*
          post请求
         */
        case .userRegister:
            return "sys/user/register"
        case .userLogin:
            return "sys/mLogin"
        case .uploadHeadImage( _):
            return "file/user/upload.jhtml"
        case .weatherData:
            return "simpleWeather/query"
        case .newsList:
            return "toutiao/index"
        case .constellationData:
            return "xzpd/query"
        /*
          put请求
         */
        case .changeAPi:
            return "sys/user/changePassword"
        /*
          get请求
         */
        case .easyRequset:
            return "data/sk/.html"
        
        }
    }
    
    var method: Moya.Method {
        switch self {
        case .easyRequset:
            return .get
        case .changeAPi:
            return .put
        default:
            return .post
        }
    }
    

    //    这个是做单元测试模拟的数据，必须要实现，只在单元测试文件中有作用
    var sampleData: Data {
        return "".data(using: String.Encoding.utf8)!
    }

    //    该条请API求的方式,把参数之类的传进来
    var task: Task {
//        return .requestParameters(parameters: nil, encoding: JSONArrayEncoding.default)
        switch self {
        /*
          get请求
         */
        case .easyRequset:
            return .requestPlain
        /*
          post请求
         */
        case let .userRegister(email, password):
            return .requestParameters(parameters: ["email": email, "password": password], encoding: JSONEncoding.default)
        case let .userLogin(parameters):
            return .requestParameters(parameters: parameters, encoding: URLEncoding.default)
        /*
          put请求
         */
        case let .changeAPi(parameters):
            return .requestParameters(parameters: parameters, encoding: URLEncoding.default)
        /*
          图片上传
         */
        case .uploadHeadImage(let parameters, let imageDate):
            ///name 和fileName 看后台怎么说，   mineType根据文件类型上百度查对应的mineType
            let formData = MultipartFormData(provider: .data(imageDate), name: "file",
                                              fileName: "hangge.png", mimeType: "image/png")
            return .uploadCompositeMultipart([formData], urlParameters: parameters)
        /*
          获取新闻列表
         */
        case .newsList(let parameters):
            return .requestParameters(parameters: parameters, encoding: URLEncoding.default)
        case .weatherData(let parameters):
            return .requestParameters(parameters: parameters, encoding: URLEncoding.default)
        case .constellationData(let parameters):
            return .requestParameters(parameters: parameters, encoding: URLEncoding.default)
        }
        
        //可选参数https://github.com/Moya/Moya/blob/master/docs_CN/Examples/OptionalParameters.md
//        case .users(let limit):
//        var params: [String: Any] = [:]
//        params["limit"] = limit
//        return .requestParameters(parameters: params, encoding: URLEncoding.default)
    }
    
    var headers: [String : String]? {
//        return ["Content-Type":"application/x-www-form-urlencoded"]
        return nil
    }
 
}
