//
//  ViewController.swift
//  WGNewsProject
//
//  Created by abox on 2020/12/29.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }


}

