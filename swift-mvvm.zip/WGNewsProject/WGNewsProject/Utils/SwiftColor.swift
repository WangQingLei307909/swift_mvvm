//
//  SwiftColor.swift
//  AmzingBox
//
//  Created by abox on 2020/7/17.
//  Copyright © 2020 abox. All rights reserved.
//

import UIKit

class SwiftColor: UIColor {
    
    // MARK:- 设置一些常用的颜色
    /// 标题：白色
    open class var TitleColor:UIColor {
        get {
            return UIColor.CSSHex("#FFFFFF")
        }
    }
    
    /// Cell下划线颜色:
    open class var CellLineColor: UIColor {
        get {
            return UIColor.CSSHex("#F5F5F5")
        }
    }
    
    /// 设置边框颜色
    open class var ViewBorder: UIColor {
        get {
            return UIColor.CSSHex("#168EFF")
        }
    }
    
    /// 设置主题颜色
    open class var ThemeColor: UIColor {
        get {
            return UIColor.CSSHex("#FFFFFF")
        }
    }
    
    /// 设置边框颜色
    open class var navgationColor: UIColor {
        get {
            return UIColor.CSSHex("#F5F5F5")
        }
    }
    
    /// 设置背景颜色
    open class var bgViewColor: UIColor {
        get {
            return UIColor.CSSHex("#f2f3f5")
        }
    }
    
}

// MARK: - 设置一些常用颜色 例如："#323232"
extension UIColor {
    
    /// 字符串转颜色
    ///
    /// - Parameter colorStr: 字符串,如#FFFFFF 或者 如#1a000000
    /// - Returns: 返回颜色
    class func CSSHex(_ colorStr: String) -> UIColor {
        var cStr : String = colorStr.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).uppercased()
        if cStr.hasPrefix("#") {
            let index = cStr.index(after: cStr.startIndex)
            //cStr = cStr.substring(from: index)
            cStr = String(cStr[index...])
        }
        if cStr.count == 6 {
            return color(cStr: cStr)
        }else if cStr.count == 8 {
            return colorWithAlpha(cStr: cStr)
        }else {
            return UIColor.black
        }
    }
    
    /// 6位字符串转颜色
    ///
    /// - Parameter cStr: 6位字符串转没有涉及透明度的颜色
    /// - Returns: 返回颜色
    private class func color(cStr: String) -> UIColor {
        var color = UIColor.white
        let rRange = cStr.startIndex ..< cStr.index(cStr.startIndex, offsetBy: 2)
        //let rStr = cStr.substring(with: rRange)
        let rStr = String(cStr[rRange])
        let gRange = cStr.index(cStr.startIndex, offsetBy: 2) ..< cStr.index(cStr.startIndex, offsetBy: 4)
        //let gStr = cStr.substring(with: gRange)
        let gStr = String(cStr[gRange])
        let bIndex = cStr.index(cStr.endIndex, offsetBy: -2)
        //let bStr = cStr.substring(from: bIndex)
        let bStr = String(cStr[bIndex...])
        var r:CUnsignedInt = 0, g:CUnsignedInt = 0, b:CUnsignedInt = 0
        Scanner(string: rStr).scanHexInt32(&r)
        Scanner(string: gStr).scanHexInt32(&g)
        Scanner(string: bStr).scanHexInt32(&b)
        color = UIColor(red: CGFloat(r) / 255.0, green: CGFloat(g) / 255.0, blue: CGFloat(b) / 255.0, alpha: CGFloat(1))
        return color
    }
    
    /// 8位字符串转颜色
    ///
    /// - Parameter cStr: 8位字符串转涉及透明度的颜色
    /// - Returns: 返回颜色
    private class func colorWithAlpha(cStr: String) -> UIColor {
        var color = UIColor.white
        let aRange = cStr.startIndex ..< cStr.index(cStr.startIndex, offsetBy: 2)
        let aStr = String(cStr[aRange])
        let rRange = cStr.index(cStr.startIndex, offsetBy: 2) ..< cStr.index(cStr.startIndex, offsetBy: 4)
        let rStr = String(cStr[rRange])
        let gRange = cStr.index(cStr.startIndex, offsetBy: 4) ..< cStr.index(cStr.startIndex, offsetBy: 6)
        let gStr = String(cStr[gRange])
        let bIndex = cStr.index(cStr.endIndex, offsetBy: -2)
        let bStr = String(cStr[bIndex...])
        var a:CUnsignedInt = 0, r:CUnsignedInt = 0, g:CUnsignedInt = 0, b:CUnsignedInt = 0
        Scanner(string: aStr).scanHexInt32(&a)
        Scanner(string: rStr).scanHexInt32(&r)
        Scanner(string: gStr).scanHexInt32(&g)
        Scanner(string: bStr).scanHexInt32(&b)
        color = UIColor(red: CGFloat(r) / 255.0, green: CGFloat(g) / 255.0, blue: CGFloat(b) / 255.0, alpha: CGFloat(a) / 255.0)
        return color
    }

    /// 随机的颜色
    class func randomColor() -> UIColor {
        let r = CGFloat(arc4random() % 256) / 255.0
        let g = CGFloat(arc4random() % 256) / 255.0
        let b = CGFloat(arc4random() % 256) / 255.0
        return UIColor(red: r, green: g, blue: b, alpha: 1.0)
    }
    
    /// 十六进制颜色 0xFFFFFF （0x六位颜色）
    class func hexadecimalColor(withHex: UInt32) -> UIColor {
        let r = ((CGFloat)((withHex & 0xFF0000) >> 16)) / 255.0
        let g = ((CGFloat)((withHex & 0xFF00) >> 8)) / 255.0
        let b = ((CGFloat)(withHex & 0xFF)) / 255.0
        return UIColor(red: r, green: g, blue: b, alpha: 1.0)
    }
    
    /// 十六进制颜色（带透明度） 0xFFFFFF （0x六位颜色）
    class func hexadecimalColorAlpha(withHex: UInt32,alpha: CGFloat) -> UIColor {
        let r = ((CGFloat)((withHex & 0xFF0000) >> 16)) / 255.0
        let g = ((CGFloat)((withHex & 0xFF00) >> 8)) / 255.0
        let b = ((CGFloat)(withHex & 0xFF)) / 255.0
        return UIColor(red: r, green: g, blue: b, alpha: alpha)
    }
    
    ///  0~255 颜色
    ///  red(0~255)
    ///  green(0~255)
    ///  blue(0~255)
    class func rgbColor(withRed: UInt8, green: UInt8, blue: UInt8) -> UIColor {
        let r = CGFloat(withRed) / 255.0
        let g = CGFloat(green) / 255.0
        let b = CGFloat(blue) / 255.0
        return UIColor(red: r, green: g, blue: b, alpha: 1.0)
    }
    
}

