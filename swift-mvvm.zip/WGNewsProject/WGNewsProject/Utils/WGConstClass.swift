//
//  SXConstClass.swift
//  SamsungSecurity
//
//  Created by abox on 2020/12/25.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

let sxUserToken = "SX_USER_TOKEN"
let sxUserName  = "SX_USER_NAME"
let sxUserPhone = "SX_USER_PHONE"
let sxUserLoginStatus = "SX_USER_LOGIN_STATUS"
