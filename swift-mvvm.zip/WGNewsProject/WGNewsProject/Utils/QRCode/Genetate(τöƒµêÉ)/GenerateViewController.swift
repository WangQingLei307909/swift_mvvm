//
//  GenerateViewController.swift
//  JunCodeDemo
//
//  Created by iOS_Tian on 2017/11/15.
//  Copyright © 2017年 CoderJun. All rights reserved.
//

import UIKit
import CLToast
class GenerateViewController: UIViewController {

    @IBOutlet weak var infoTextField: UITextField!
    @IBOutlet weak var codeImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addCustemNavgation()
    }

    func addCustemNavgation() {
        let custemNav = WGCustemNavgation.init(frame: CGRect.init(x: 0, y: 0, width: Int(kScreenWidth), height: SafeAreaTopHeight))
        self.view.addSubview(custemNav)
        custemNav.setNavgationTitle(titleString: "生成二维码")
        custemNav.changeBlock = { [weak self] flag in
            if flag {
                self!.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    @IBAction func getQRCodeImageAction(_ sender: Any) {
        if SwiftTool.isEmptyOrNull(value: infoTextField.text as AnyObject) {
            CLToast.cl_show(msg: "二维码信息不能为空")
            return
        }
        let fgImage = UIImage(named: "icon1024")
        let codeMan = CodeManage()
        codeImage.image = codeMan.generateCode(inputMsg: infoTextField.text!, fgImage: fgImage)
    }
}
