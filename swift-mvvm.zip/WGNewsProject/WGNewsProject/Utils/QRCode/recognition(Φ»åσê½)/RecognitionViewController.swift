//
//  RecognitionViewController.swift
//  JunCodeDemo
//
//  Created by iOS_Tian on 2017/11/15.
//  Copyright © 2017年 CoderJun. All rights reserved.
//

import UIKit

class RecognitionViewController: UIViewController {

    @IBOutlet weak var codeImageView: UIImageView!
    @IBOutlet weak var codeInfoLabel: UILabel!
    //3. 创建照片选择器
    var imagePC = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
        addCustemNavgation()
    }
    
    func addCustemNavgation() {
        let custemNav = WGCustemNavgation.init(frame: CGRect.init(x: 0, y: 0, width: Int(kScreenWidth), height: SafeAreaTopHeight))
        self.view.addSubview(custemNav)
        custemNav.setNavgationTitle(titleString: "识别二维码", rightString:"生成二维码" )
        custemNav.changeBlock = {[weak self] flag in
            if flag {
                self!.navigationController?.popViewController(animated: true)
            } else {
                let vc = GenerateViewController()
                self!.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    
    //选择图片
    @IBAction func selectivePictudeAction(_ sender: UIButton) {
        // 1.判断点的哪一个按钮
        let sourceType: UIImagePickerController.SourceType = sender.tag == 201 ? .camera : .photoLibrary
        
        //2. 判断是否允许该操作
        if !UIImagePickerController.isSourceTypeAvailable(sourceType) {
            print("操作限制, 不可执行")
            return
        }
        //3.1 设置数据源
        imagePC.sourceType = sourceType
        //3.2 设置代理
        imagePC.delegate = self
        //3.3 的弹出控制器
        present(imagePC, animated: true, completion: nil)
    }
    
    //识别二维码信息
    @IBAction func recognitionCodeAction(_ sender: Any) {
        let codeMan = CodeManage()
        guard let image = codeImageView.image else { return }
        //获取二维码信息
        guard let infoArr = codeMan.recognitionQRCode(qrCodeImage: image) else { return }
        for text in infoArr {
            print(text)
            codeInfoLabel.text = infoArr.first
        }
    }
}


//MARK: 实现代理
extension RecognitionViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info:  [UIImagePickerController.InfoKey : Any]) {

        guard  let selectedImage = info[.originalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        codeImageView.image = selectedImage
        dismiss(animated: true, completion: nil)
    }
    
    //选取完成后调用
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
