//
//  WGSelectConstellationVC.swift
//  WGNewsProject
//
//  Created by abox on 2021/1/4.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import Then
import SnapKit
class WGSelectConstellationVC: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return array.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return array[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        constellation = array[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int,
                    forComponent component: Int, reusing view: UIView?) -> UIView {
        var pickerLabel = view as? UILabel
        if pickerLabel == nil {
            pickerLabel = UILabel()
            pickerLabel?.font = UIFont.systemFont(ofSize: 15)
            pickerLabel?.textAlignment = .center
        }
        pickerLabel?.text = array[row]
        pickerLabel?.textColor = UIColor.CSSHex("#323232")
        return pickerLabel!
    }
    
    @IBAction func closeAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func submitAction(_ sender: UIButton) {
        if !SwiftTool.isEmptyOrNull(value: constellation as AnyObject) {
            selectBlock!(constellation)
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    typealias SelectBlock = (String)->()
    var selectBlock : SelectBlock?
    var array = ["白羊","金牛","双子","巨蟹","狮子","处女","天秤","天蝎","人马","山羊","水瓶","双鱼"]
    var constellation = "白羊"
    
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var closeButton: UIButton!
    
    init() {
        super.init(nibName: nil, bundle: nil)
        self.modalPresentationStyle = .custom
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- Swift语法糖---初始化Then 和swift自动布局 SnapKit
    /*
     let redView = UIView().then { (make) in
         make.backgroundColor = .red
         make.frame = CGRect(x: 50, y: 50, width: 100, height: 100)
         self.view.addSubview(make)
         make.snp.makeConstraints({ (make) in
             make.top.left.right.equalTo(0)
             make.height.equalTo(100)
         })
     }
     */
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        SwiftTool.theViewSetsTheBorderLineAndWidth(view: closeButton, color: UIColor.CSSHex("#323232"), width: 1)
    }
    
}
