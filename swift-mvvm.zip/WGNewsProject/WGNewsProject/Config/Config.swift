//
//  Config.swift
//  SamsungSecurity
//
//  Created by abox on 2020/12/25.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

// MARK: - 请求网络数据回掉
///成功数据的回调
typealias SuccessCallback = (Any) -> (Void)
///失败的回调
typealias FailedCallback  = (String) -> (Void)
///网络错误的回调
typealias ErrorCallback   = (String) -> (Void)

// MARK: - 获取屏幕宽度和高度
let kScreenWidth  = UIScreen.main.bounds.size.width
let kScreenHeight = UIScreen.main.bounds.size.height

//MARK:-此处是跑真虚拟机
let screenBounds = UIScreen.main.bounds
let SafeAreaTopHeight      = SwiftTool.isItSpecialCurvedScreen() ? 88 : 88
let SafeAreaStatusHeight   = SwiftTool.isItSpecialCurvedScreen() ? 44 : 20
let SafeAreaMoreThanHeight = SwiftTool.isItSpecialCurvedScreen() ? 20 : 0
let SafeAreaBottomHeight   = SwiftTool.isItSpecialCurvedScreen() ? 34 : 0

// MARK: - 获取系统版本号和历史版本号
//获取当前版本号
let currentVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
//获取历史版本号
let sandboxVersion = UserDefaults.standard.object(forKey: "CFBundleShortVersionString") as? String ?? ""

// MARK: - 获取APP信息、名称、版本号以及build版本号
//获取app信息
let infoDictionary : Dictionary = Bundle.main.infoDictionary!
//程序名称
let appDisplayName : String = infoDictionary["CFBundleDisplayName"] as! String
//版本号
let majorVersion : String = infoDictionary ["CFBundleShortVersionString"] as! String
//build号
let minorVersion : String = infoDictionary ["CFBundleVersion"] as! String

// MARK: - 获取设备信息
//ios版本
let iosVersion : NSString = UIDevice.current.systemVersion as NSString
//设备udid
let identifierNumber  = UIDevice.current.identifierForVendor
//设备名称
let deviceName : String = UIDevice.current.name
//系统名称
let systemName : String = UIDevice.current.systemName
//设备型号
let model = UIDevice.current.model
//设备区域化型号如A1533
let localizedModel = UIDevice.current.localizedModel
