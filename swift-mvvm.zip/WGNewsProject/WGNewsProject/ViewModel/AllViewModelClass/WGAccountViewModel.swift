//
//  WGAccoutnViewModel.swift
//  WGWeather
//
//  Created by abox on 2020/12/26.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

class WGAccountViewModel: WGViewModelClass {

    // MARK: - 用户登陆
    /// 登陆
    /// - Parameters:
    ///   - paramterDic:  参数
    ///   - successBlock: 成功返回数据
    ///   - failedBlock:  请求返回报错数据
    ///   - errorBlock:   网络请求返回保存信息
    public static func userLogin(paramterDic:NSDictionary,successBlock:@escaping SuccessCallback,failedBlock:@escaping FailedCallback,errorBlock:@escaping ErrorCallback){
        NetWorkRequest(.userLogin(parameters: paramterDic as! [String : Any]), completion: { ( success ) -> (Void) in
            print(success)
            successBlock("发布成功")
        }, failed: { ( failmsg ) -> (Void) in
            failedBlock(failmsg)
        }) { ( errormeg ) -> (Void) in
            errorBlock(errormeg)
        }
    }
    
}
