//
//  WGNewsViewModelClass.swift
//  WGNewsProject
//
//  Created by abox on 2020/12/30.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit
import WisdomHUD
import CLToast
class WGNewsViewModelClass: WGViewModelClass {
    
    // MARK: - 请求首页数据
    /// 请求首页数据接口
    /// - Parameter paramterDic: 参数
    func getNewsListData(paramterDic:NSDictionary) {
        WisdomHUD.showLoading(text: "加载中", enable: true)
        NetWorkRequest(.newsList(parameters: paramterDic as! [String : Any]), completion: { ( success) -> (Void) in
            self.returnNewsListData(responseObject: success)
        }, failed: { (failmsg) -> (Void) in
            CLToast.cl_show(msg: failmsg)
            self.failMessage(failMsg: failmsg)
        }) { (errormsg) -> (Void) in
            CLToast.cl_show(msg: errormsg)
            self.errorMessage(errorMsg: errormsg)
        }
    }
    
    /// 请求数据成功后，在此方法里对数据进行解析，放回想要的数据格式
    /// - Parameter responseObject: 返回成功的数据
    func returnNewsListData(responseObject:String) {
        //可以直接返回数据，也可以再次对数据进行解析即可
        let responseDic = SwiftTool.jsonStringToDict(jsonString: responseObject)
        let dataSource = NSMutableArray()
        if  SwiftTool.dictionaryIsEmpty(value: responseDic.object(forKey: "result") as AnyObject?)  {
            self.failMessage(failMsg: "获取失败")
        } else {
            let resultDic = responseDic.object(forKey: "result") as! NSDictionary
            if resultDic["stat"] as! String == "1" {
                WisdomHUD.dismiss()
                let array = resultDic["data"] as! NSArray
                for item in array {
                    let model = WGNewsModel.jsonDataToModel(paramterDic: item as! NSDictionary)
                    dataSource.add(model)
                }
                qsuccessCallBack!(dataSource)
            } else {
                self.failMessage(failMsg: "获取失败")
            }
        }
    }
    
    // MARK: - 获取当前和未来天气
    func getCurrentAndFutureWeather(paramterDic:NSDictionary) {
        WisdomHUD.showLoading(text: "加载中", enable: true)
        NetWorkRequest(.weatherData(parameters: paramterDic as! [String : Any]), completion: { ( success) -> (Void) in
            self.returnWeatherData(responseObject: success)
        }, failed: { (failmsg) -> (Void) in
            self.failMessage(failMsg: failmsg)
        }) { (errormsg) -> (Void) in
            self.errorMessage(errorMsg: errormsg)
        }
    }
    
    /// 请求数据成功后，在此方法里对数据进行解析，放回想要的数据格式
    /// - Parameter responseObject: 返回成功的数据
    func returnWeatherData(responseObject:String) {
        //可以直接返回数据，也可以再次对数据进行解析即可
        let responseDic = SwiftTool.jsonStringToDict(jsonString: responseObject)
        if  SwiftTool.dictionaryIsEmpty(value: responseDic.object(forKey: "result") as AnyObject?)  {
            self.failMessage(failMsg: "获取失败")
        } else {
            if responseDic["error_code"] as! Int == 0 {
                WisdomHUD.dismiss()
                let resultDic = responseDic.object(forKey: "result") as! NSDictionary
                qsuccessCallBack!(WGWeatherModel.jsonDataToModel(paramterDic: resultDic))
            } else {
                self.failMessage(failMsg: "获取失败")
            }
        }
    }
    
    /// 获取天气预报
    /// - Parameters:
    ///   - successBlock: 成功
    ///   - failedBlock: 失败
    ///   - errorBlock: 失败
    public static func getWeatherData(successBlock:@escaping SuccessCallback,failedBlock:@escaping FailedCallback,errorBlock:@escaping ErrorCallback){
        WisdomHUD.showLoading(text: "加载中", enable: true)
        NetWorkRequest(.easyRequset, completion: { ( success ) -> (Void) in
            WisdomHUD.dismiss()
            successBlock(success)
        }, failed: { ( failmsg ) -> (Void) in
            WisdomHUD.dismiss()
            failedBlock(failmsg)
        }) { ( errormeg ) -> (Void) in
            WisdomHUD.dismiss()
            errorBlock(errormeg)
        }
    }
    
    /// 请求接口，接口返回报错信息
    /// - Parameter failMsg: 报错信息
    func failMessage(failMsg:String) {
        WisdomHUD.dismiss()
        qfailedCallback!(failMsg)
    }
    
    /// 网络请求报错信息（超时等）
    /// - Parameter errorMsg: 报错信息
    func errorMessage(errorMsg:String) {
        WisdomHUD.dismiss()
        qerrorCallback!(errorMsg)
    }
}
