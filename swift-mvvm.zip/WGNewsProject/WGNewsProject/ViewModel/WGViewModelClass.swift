//
//  ViewModelClass.swift
//  AmzingBox
//
//  Created by abox on 2020/7/9.
//  Copyright © 2020 abox. All rights reserved.
//

import UIKit

class WGViewModelClass: NSObject {
    
    var qsuccessCallBack : SuccessCallback? // 成功闭包
    var qfailedCallback  : FailedCallback?  // 请求失败闭包
    var qerrorCallback   : ErrorCallback?   // 网络报错闭包
    
    /// 通过此函数将返回的数据通过闭包返回
    /// - Parameters:
    ///   - successCallBack: 成功闭包
    ///   - failedCallback: 失败闭包
    ///   - errorCallback: 网络错误闭包
    func setCallBackData(successCallBack:@escaping SuccessCallback,failedCallback:@escaping FailedCallback,errorCallback:@escaping ErrorCallback) {
        qsuccessCallBack = successCallBack
        qfailedCallback  = failedCallback
        qerrorCallback   = errorCallback
    }
    
}
