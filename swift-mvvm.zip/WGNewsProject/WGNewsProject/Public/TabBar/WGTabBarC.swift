//
//  WGTabBarC.swift
//  WGWeather
//
//  Created by abox on 2020/12/26.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

class WGTabBarC: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        creaTabBarController()
    }
    
    /// 创建分栏控制器
    func creaTabBarController() {
        self.tabBar.tintColor = UIColor.CSSHex("#323232")
        self.tabBar.barTintColor = UIColor.CSSHex("#F5F5F5")
        addChildController(ChildController: WGNewsVC(), Title: "首页", DefaultImage: UIImage.init(named: "ic_home_0")!, SelectedImage: UIImage.init(named: "ic_home_1")!)
        addChildController(ChildController: WGHomeVC(), Title: "天气", DefaultImage: UIImage.init(named: "ic_message_0")!, SelectedImage: UIImage.init(named: "ic_message_1")!)
        addChildController(ChildController: WGMyVC(), Title: "我的", DefaultImage: UIImage.init(named: "ic_me_0")!, SelectedImage: UIImage.init(named: "ic_me_1")!)
    }
    
    /// 设置分栏控制样式
    /// - Parameters:
    ///   - child: 控制器
    ///   - title: 标题
    ///   - defaultImage: 默认t图片
    ///   - selectedImage: 选中后图片
    func addChildController(ChildController child:UIViewController, Title title:String, DefaultImage defaultImage:UIImage, SelectedImage selectedImage:UIImage){
        //设置名字标题、选中和未选中图片
        child.tabBarItem = UITabBarItem(title: title, image: defaultImage.withRenderingMode(.alwaysOriginal), selectedImage: selectedImage.withRenderingMode(.alwaysOriginal))
        //设置选中和未选中文字颜色和字体大小
    child.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor:UIColor.black,NSAttributedString.Key.font:UIFont.systemFont(ofSize: 14)], for: .selected)
    child.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor:UIColor.CSSHex("#999999"),NSAttributedString.Key.font:UIFont.systemFont(ofSize: 14)], for: .normal)
        self.addChild(child)
    }

}
