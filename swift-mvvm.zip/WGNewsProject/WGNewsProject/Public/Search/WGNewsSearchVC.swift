//
//  WGNewsSearchVC.swift
//  WGNewsProject
//
//  Created by abox on 2020/12/29.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit
import CLToast
class WGNewsSearchVC: ViewController,cancelTable {
    
    func cancelOrSearch(flag: Bool, resultString: String) {
        self.navigationController?.popViewController(animated: true)
    }

    typealias SearchBlock   = (String)->()
    var searchBlock : SearchBlock?
    public var contentString = String()
    var dataSource = NSMutableArray()
    let headerIdentifier = "WGNewsSearchReusableView"
    let identifier = "WGNewsSearchViewCell"
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var height: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpCommonData()
        setUpCollectionView()
        getSearchData()
    }
    
    func setUpCommonData() {
        height.constant = CGFloat(SafeAreaTopHeight)
        let search = WGSearchResultView.init(frame: CGRect(x: 0, y: 0, width: Int(kScreenWidth), height: SafeAreaTopHeight))
        search.delegate = self
        self.view.addSubview(search)
    }
    
    func setUpCollectionView() {
        collectionView!.register(WGNewsSearchReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: headerIdentifier)
        collectionView.register(UINib.init(nibName: identifier, bundle: nil), forCellWithReuseIdentifier: identifier)
    }
    
    func getSearchData() {
        let topArray = [["title":"GameOn登录iOS","flag":true],["title":"iOS14.5正式版发送","flag":false]]
        let history  = [["title":"iOS14.5 Beta3发布","flag":false],["title":"iOS分屏怎么用","flag":false],
                        ["title":"viov UI","flag":false],["title":"oppo UI","flag":false],
                        ["title":"iOS14.5","flag":false],["title":"mac pro 最新","flag":false],
                        ["title":"mac pro 方形","flag":false]]
        let hotArray = [["title":"iPad Mini Pro被曝","flag":true],["title":"iOS14.5 Beta3","flag":false],
                        ["title":"沈阳彩民中1800万","flag":false],["title":"地球超清壁纸","flag":false],
                        ["title":"OPPO Find X3 将发布","flag":false],["title":"速度与激情9在改档","flag":false],
                        ["title":"华为回应养猪传闻","flag":true],["title":"速度与激情9在改档","flag":false],
                        ["title":"全屏渐变色壁纸","flag":false]]
        dataSource.add(topArray)
        dataSource.add(history)
        dataSource.add(hotArray)
    }
    
    deinit {
        print("释放了")
    }
}

extension WGNewsSearchVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let array = dataSource[section] as! Array<Any>
        return array.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as! WGNewsSearchViewCell
        let array = dataSource[indexPath.section] as! Array<Any>
        let dic = array[indexPath.row] as! NSDictionary
        cell.setCellData(search: dic["title"] as! String, flagLine: indexPath.row % 2 != 0, hotBool: dic["flag"] as! Bool  )
        return cell
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return dataSource.count
    }

    //每个分区的内边距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0);
    }
    
    //最小 item 间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0;
    }
    
    //最小行间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0;
    }
    //item 的尺寸
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return WGNewsSearchViewCell.cellHeight()
    }
    
    //每个分区区头尺寸
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize (width: kScreenWidth, height: section == 0 ? 0 : 40)
    }
    
    //返回区头、区尾实例
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        autoreleasepool {
            var headView = WGNewsSearchReusableView()
            if kind == UICollectionView.elementKindSectionHeader {
                headView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: headerIdentifier, for: indexPath) as! WGNewsSearchReusableView
                headView.titleLabel?.text = indexPath.section == 0 ? "" : indexPath.section == 1 ? "搜索历史" : "猜你想看"
            }
            return headView
        }
    }

    //item 对应的点击事件
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let array = dataSource[indexPath.section] as! Array<Any>
        let dic = array[indexPath.row] as! NSDictionary
        let searchResult = WGSearchResultVC()
        searchResult.searchString = (dic["title"] as! String)
        self.navigationController?.pushViewController(searchResult, animated: false)
    }
    
}
