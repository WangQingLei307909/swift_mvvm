//
//  WGNewsSearchViewCell.swift
//  WGNewsProject
//
//  Created by abox on 2021/3/5.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class WGNewsSearchViewCell: UICollectionViewCell {

    @IBOutlet weak var verticalLine: UIView!
    @IBOutlet weak var hotImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    public static func cellHeight()-> CGSize {
        return CGSize.init(width: 0.5 * kScreenWidth, height: 40)
    }
    
    func setCellData(search:String,flagLine:Bool,hotBool:Bool) {
        titleLabel.text = search
        verticalLine.isHidden = flagLine
        hotImageView.isHidden = !hotBool
    }
    
}
