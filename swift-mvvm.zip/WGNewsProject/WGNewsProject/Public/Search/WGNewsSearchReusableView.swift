//
//  WGNewsSearchReusableView.swift
//  WGNewsProject
//
//  Created by abox on 2021/3/5.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class WGNewsSearchReusableView: UICollectionReusableView {
    
    var titleLabel:UILabel?

    override init(frame: CGRect) {
        super.init(frame: frame)
        initView()
    }
    
    func initView(){
        titleLabel = UILabel(frame: CGRect.init(x: 15, y: 0, width: kScreenWidth - 30, height: 40))
        titleLabel?.textColor = .CSSHex("#323232")
        self .addSubview(titleLabel!)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
