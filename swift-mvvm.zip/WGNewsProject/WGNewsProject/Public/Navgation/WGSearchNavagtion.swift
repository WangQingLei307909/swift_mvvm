//
//  WGSearchNavagtion.swift
//  WGNewsProject
//
//  Created by abox on 2021/3/9.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class WGSearchNavagtion: UIView {

    typealias SearchClosure = (String) -> Void
    var searchClosure:SearchClosure?
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBAction func searchAction(_ sender: UIButton) {
        guard let searchClosure = searchClosure else {
            return
        }
        searchClosure(searchTextField.text ?? "")
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        // 加载xib
        contentView = (Bundle.main.loadNibNamed("WGSearchNavagtion", owner: self, options: nil)?.last as! UIView)
        contentView.frame = frame// 设置frame
        contentView.backgroundColor = SwiftColor.ThemeColor
        addSubview(contentView)// 添加上去
        SwiftTool.theViewSetsTheBorderLineAndWidth(view: searchView, color: SwiftColor.navgationColor, width: 1)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
