//
//  WGSearchResultView.swift
//  WGNewsProject
//
//  Created by abox on 2021/3/9.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

@objc protocol cancelTable {
    func cancelOrSearch(flag:Bool,resultString:String)
}


class WGSearchResultView: UIView {
    weak var delegate: cancelTable?
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var resultTextField: UITextField!
    @IBOutlet weak var searchView: UIView!
    @IBAction func cancelAction(_ sender: UIButton) {
        resultTextField.resignFirstResponder()
        delegate?.cancelOrSearch(flag: false, resultString: resultTextField.text ?? "")
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView = (Bundle.main.loadNibNamed("WGSearchResultView", owner: self, options: nil)?.last as! UIView)
        contentView.frame = frame
        contentView.backgroundColor = SwiftColor.navgationColor
        addSubview(contentView)
        SwiftTool.theViewSetsTheBorderLineAndWidth(view: searchView, color: SwiftColor.navgationColor, width: 1)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


extension WGSearchResultView: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        delegate?.cancelOrSearch(flag: true, resultString: textField.text ?? "")
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.endEditing(true)
    }
}
