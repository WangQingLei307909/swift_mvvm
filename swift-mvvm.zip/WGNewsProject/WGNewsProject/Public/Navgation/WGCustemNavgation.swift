//
//  WGCustemNavgation.swift
//  WGWeather
//
//  Created by abox on 2020/12/26.
//  Copyright © 2020 wql. All rights reserved.
//

import UIKit

class WGCustemNavgation: UIView {
    //给闭包起一个别名
    typealias didSelectActionWithIndex = (Bool) -> ()
    //闭包属性
    var changeBlock: didSelectActionWithIndex?
    @IBOutlet weak var titleLabel:     UILabel!
    @IBOutlet weak var contentView:    UIView!
    @IBOutlet weak var rightButton: UIButton!
    
    // MARK: - 创建左按钮点击事件
    /// 点击关闭View
    ///
    /// - Parameter sender: sender description
    @IBAction func backAction(_ sender: Any) {
        ///判断闭包是否为空
        guard let changeBlock = changeBlock else {
            return
        }
        changeBlock(true)
    }
    
    // MARK: - 创建右按钮点击事件
    /// 点击关闭View
    ///
    /// - Parameter sender: sender description
    @IBAction func otherAction(_ sender: Any) {
        ///判断闭包是否为空
        guard let  changeBlock =  changeBlock else {
            return
        }
        changeBlock(false)
    }
    
    // MARK: - 创建自定义导航
    override init(frame: CGRect) {
        super.init(frame: frame)
        // 加载xib
        contentView = (Bundle.main.loadNibNamed("WGCustemNavgation", owner: self, options: nil)?.last as! UIView)
        contentView.frame = frame// 设置frame
        contentView.backgroundColor = SwiftColor.ThemeColor
        addSubview(contentView)// 添加上去
    }
    
    /// 设置标题
    /// - Parameter titleString: 标题内容
    public func setNavgationTitle(titleString:String,rightString:String? = nil ) {
        titleLabel.text = titleString
        guard let rightString = rightString else {
            return
        }
        rightButton.isHidden = SwiftTool.isEmptyOrNull(value: rightString as AnyObject)
        rightButton.setTitle(rightString, for: UIControl.State.normal)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
